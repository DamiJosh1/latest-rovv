// src/components/layout/Header.tsx
'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, ChevronDown } from 'lucide-react'
import RovvLogo from '../../assets/logo/rovv.svg?react'

const navItems = [
  { name: 'Get to know ROVV', href: '/get-to-know-rovv' },
  { name: 'Cities', href: '/cities' },
  {
    name: 'More',
    items: [
      { name: 'Fleet management', href: '/fleet-management' },
      { name: 'Partnership', href: '/partnership' },
      { name: 'Drive', href: '/drive' },
      { name: 'Sustainability', href: '/sustainability' },
      { name: 'How ROVV works', href: '/how-it-works' },
    ]
  }
]

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const [showModal, setShowModal] = useState(false)
   const [qrTab, setQrTab] = useState<'For Passengers' | 'For Drivers'>('For Passengers')

  return (
    <>
      {/* MAIN HEADER */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-bg backdrop-blur-md border-b border-bg">
        <div className="max-w-7xl mx-auto px-6 lg:px-5 py-5 flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="shrink-0">
            <RovvLogo className="h-9 lg:h-10 w-auto" />
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-10">
            {navItems.map((item) => (
              <div key={item.name} className="relative">
                {item.items ? (
                  <button
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                    className="flex items-center gap-1 text-dark font-bold font-sans hover:text-primary transition"
                  >
                    {item.name} <ChevronDown size={16} className={`transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                ) : (
                  <a href={item.href} className="text-dark font-bold font-sans hover:text-primary transition">
                    {item.name}
                  </a>
                )}

                {/* Dropdown */}
                <AnimatePresence>
                  {item.items && dropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full left-1/12 -translate-x-1/2 mt-4 w-55 font-bold font-sans bg-bg rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
                      onClick={() => setDropdownOpen(false)}
                    >
                      {item.items.map((sub) => (
                        <a
                          key={sub.name}
                          href={sub.href}
                          className="block px-6 py-2 text-dark hover:bg-purple-50 hover:text-primary transition first:pt-5 last:pb-5"
                        >
                          {sub.name}
                        </a>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}

            {/* Get the app button */}
            <button
              onClick={() => setShowModal(true)}
              className="bg-primary rounded-lg  text-bg  hover:bg-accent px-6 py-3  font-bold transition shadow-sm"
            >
              Get the app
            </button>
          </nav>

          {/* Mobile menu button */}
          <button aria-label='Menu btn'
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2"
          >
            <Menu size={28} className="text-primary" />
          </button>
        </div>
      </header>

      {/* MOBILE MENU */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 bg-white "
            />

            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.35 }}
              className="fixed right-0 top-0 bottom-0 w-[410px] md:w-[760px]  max-w-[100vw] min-w-[320px] h-165 bg-white z-50 "
            >
              <div className="flex items-center bg-bg justify-between p-[22.3px] ">
                <RovvLogo className="h-10" />
                <button aria-label='X'
                onClick={() => setMobileOpen(false)} className="">
                  <X size={27} />
                </button>
              </div>

              <nav className="px-6 py-8 space-y-2" >
                {navItems.map((item) => (
              <div key={item.name} className="relative">
                {item.items ? (
                  <button
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                    className="flex items-center gap-1 text-dark font-bold font-nohemi text-2xl transition"
                  >
                    {item.name} <ChevronDown size={16} className={`transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                ) : (
                  <a href={item.href} className="text-dark text-2xl font-bold font-nohemi transition">
                    {item.name}
                  </a>
                )}

                {/* Dropdown */}
                <AnimatePresence>
                  {item.items && dropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full left-27 -translate-x-1/2 mt-4 w-55 font-bold font-sans bg-bg rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
                      onClick={() => setDropdownOpen(false)}
                    >
                      {item.items.map((sub) => (
                        <a
                          key={sub.name}
                          href={sub.href}
                          className="block px-6 py-2 text-dark transition first:pt-5 last:pb-5"
                        >
                          {sub.name}
                        </a>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}

                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  onClick={() => {
                    setShowModal(true)
                    setMobileOpen(false)
                  }}
                  className="w-full mt-8 font-sans border-2 bg-purple text-bg py-4 rounded-xl font-bold   transition"
                >
                  Get the app
                </motion.button>
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ========= MODAL ========= */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center px-6">
          <motion.div
            initial={{ scale: 0.85, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.35 }}
            className="bg-white w-full max-w-sm sm:max-w-md rounded-2xl p-6 relative"
          >
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 text-gray-700 text-xl"
            >
              ×
            </button>

            <h2 className="text-center text-2xl font-nohemi font-bold mb-6">
              Get the ROVV App
            </h2>

            {/* Tabs */}
            <div className="flex justify-center gap-6 mb-6">
              {['For Passengers', 'For Drivers'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setQrTab(tab as 'For Passengers')}
                  className="font-bold text-sm pb-1 relative"
                >
                  {tab}

                  <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-medium" />

                  <motion.div
                    className="absolute bottom-0 left-0 right-0 h-[2px] bg-primary"
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: qrTab === tab ? 1 : 0 }}
                    transition={{ duration: 0.3 }}
                  />
                </button>
              ))}
            </div>

            <div className="flex justify-center mb-4">
              <div className="w-40 h-40 bg-bg rounded-lg flex items-center justify-center">
                <p className="text-medium text-sm">QR Code</p>
              </div>
            </div>

            <p className="text-center text-medium font-sans text-sm">
              Scan the QR code to download the ROVV app.
            </p>
          </motion.div>
        </div>
      )}
      </>
  )
}