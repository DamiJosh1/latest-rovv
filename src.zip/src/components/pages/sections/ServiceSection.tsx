// src/components/sections/ServicesSection.tsx  

'use client'
import { useEffect } from 'react'

import ridesImg from '../../../assets/images/pic (1).png'
import intercityImg from '../../../assets/images/pictures (1).jpg'
import deliveryImg from '../../../assets/images/me.png'
import rentalImg from '../../../assets/images/pic (3).jpg'
import fleetImg from '../../../assets/images/pic (2).jpg'
import airportImg from '../../../assets/images/pictures (2).jpg'

const services = [
  { title: 'City Rides', desc: 'Quick, comfortable rides across the city', img: ridesImg },
  { title: 'Inter-city Rides', desc: 'Smooth trips between cities', img: intercityImg },
  { title: 'Delivery', desc: 'Fast, reliable deliveries right to your doorstep', img: deliveryImg },
  { title: 'Car rental', desc: 'Easy rentals, anytime you need', img: rentalImg },
  { title: 'Fleet management', desc: 'Smart car control for your fleet', img: fleetImg },
  { title: 'Airport Transfer', desc: 'On-time pickups and drop-offs for travelers', img: airportImg },
]

export default function ServicesSection() {

  useEffect(() => {
    const cards = document.querySelectorAll('.service-card')

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in')
          }
        })
      },
      { threshold: 0.15 }
    )

    cards.forEach((card) => {
      if (card.getBoundingClientRect().top < window.innerHeight) {
        card.classList.add('animate-in')
      }
        observer.observe(card)
    })
    return () => cards.forEach((card) => observer.unobserve(card))
  }, [])

  return (
    <section className="py-19 px-4 bg-bg overflow-hidden">
      <div className="max-w-7xl mx-auto">

        {/* Top Badge */}
        <div className="text-center mb-6">
          <span className="inline-flex items-center gap-2 font-sans font-bold bg-dark text-bg px-4 py-2 rounded-[40px] text-sm">
            ROVV app
          </span>
        </div>

        {/* Title */}
        <h2 className="text-center text-[23px] font-nohemi font-bold lg:text-5xl text-dark mb-16 leading-tight">
          Every journey, one ROVV app
        </h2>

        {/* Grid: mobile = 1, tablet = 2, desktop = 3 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 justify-center ">
          {services.map((s, i) => (
            <article
              key={i}
              className="service-card group w-full bg-bg rounded-2xl border  border-light  shadow-xl overflow-hidden
                         flex flex-col transition-all duration-500 hover:shadow-2xl
                         opacity-0 translate-y-12"
            >
              {/* IMAGE */}
              <div className="w-full h-[350px]  overflow-hidden">
                <img
                  src={s.img}
                  alt={s.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>

              {/* CONTENT */}
              <div className="px-6 pt-6 pb-8 flex flex-col gap-3">
                <h3 className="text-2xl font-nohemi font-bold text-dark group-hover:text-primary transition-colors duration-300">
                  {s.title}
                </h3>

                <p className="text-base font-medium">{s.desc}</p>

                {/* UNDERLINE-LINE ANIMATED LINK */}
                <button
                  className="relative mt-4  w-fit text-medium font-bold text-sm
                             after:absolute after:left-0 after:bottom-0 after:h-0.5 after:w-0
                             after:bg-medium after:transition-all after:duration-300
                             hover:after:w-full "
                >
                  Learn more
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>

      
    </section>
  )
}